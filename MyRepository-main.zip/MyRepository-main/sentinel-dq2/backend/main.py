"""Sentinel DQ2 - Gestao de Qualidade de Dados RC 18."""
import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path

import requests as http_requests
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional

from backend.db import query, execute, execute_returning, close_pool, get_workspace_client, run_dbsql_query

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

FRONTEND_DIR = Path(__file__).parent.parent / "frontend" / "dist"


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Sentinel DQ2 starting up...")
    logger.info("FRONTEND_DIR: %s exists=%s", FRONTEND_DIR, FRONTEND_DIR.exists())
    yield
    logger.info("Shutting down...")
    close_pool()


app = FastAPI(title="Sentinel DQ2", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _ser(rows):
    result = []
    for row in rows:
        r = {}
        for k, v in row.items():
            if hasattr(v, "isoformat"):
                r[k] = v.isoformat()
            elif isinstance(v, (int, float, str, bool, type(None), list, dict)):
                r[k] = v
            else:
                r[k] = str(v)
        result.append(r)
    return result


@app.get("/api/health")
def health():
    return {"status": "healthy", "app": "sentinel-dq2"}


@app.get("/api/debug")
def debug():
    """Debug endpoint to test DB connection."""
    import traceback
    try:
        rows = query("SELECT 1 AS test")
        return {"db": "ok", "result": rows}
    except Exception as e:
        return {"db": "error", "error": str(e), "traceback": traceback.format_exc()}


@app.get("/api/dashboard")
def get_dashboard():
    overall_rows = query("""
        SELECT ROUND(AVG(score)::numeric, 1) AS avg_score
        FROM dq_quality_results
        WHERE result_date = (SELECT MAX(result_date) FROM dq_quality_results)
    """)
    overall_score = float(overall_rows[0]["avg_score"]) if overall_rows and overall_rows[0]["avg_score"] else 0

    domain_scores = query("""
        SELECT d.id, d.name, d.owner_email,
               ROUND(AVG(r.score)::numeric, 1) AS score
        FROM dq_data_domains d
        JOIN dq_quality_results r ON r.domain_id = d.id
        WHERE r.result_date = (SELECT MAX(result_date) FROM dq_quality_results)
        GROUP BY d.id, d.name, d.owner_email ORDER BY d.name
    """)

    kpi_summary = query("""
        SELECT kpi_type,
               ROUND(AVG(score)::numeric, 1) AS avg_score,
               SUM(rules_evaluated) AS total_rules,
               SUM(rules_passed) AS total_passed,
               SUM(rules_failed) AS total_failed
        FROM dq_quality_results
        WHERE result_date = (SELECT MAX(result_date) FROM dq_quality_results)
        GROUP BY kpi_type ORDER BY kpi_type
    """)

    recent_incidents = query("""
        SELECT i.id, i.title, i.severity, i.status, i.created_at,
               d.name AS domain_name
        FROM dq_quality_incidents i
        JOIN dq_data_domains d ON i.domain_id = d.id
        ORDER BY i.created_at DESC LIMIT 5
    """)

    kpi_trend = query("""
        SELECT result_date, ROUND(AVG(score)::numeric, 1) AS avg_score
        FROM dq_quality_results
        WHERE result_date >= CURRENT_DATE - INTERVAL '30 days'
        GROUP BY result_date ORDER BY result_date
    """)

    stats = query("""
        SELECT
          (SELECT COUNT(*) FROM dq_quality_rules WHERE status = 'approved') AS total_rules,
          (SELECT COUNT(*) FROM dq_quality_incidents WHERE status NOT IN ('resolved')) AS open_incidents,
          (SELECT COUNT(*) FROM dq_quality_incidents WHERE severity = 'critical' AND status NOT IN ('resolved')) AS critical_incidents,
          (SELECT COUNT(*) FROM dq_quality_executions WHERE executed_at >= NOW() - INTERVAL '24 hours') AS executions_24h
    """)

    return {
        "overall_score": overall_score,
        "domain_scores": _ser(domain_scores),
        "kpi_summary": _ser(kpi_summary),
        "recent_incidents": _ser(recent_incidents),
        "kpi_trend": _ser(kpi_trend),
        "stats": _ser(stats)[0] if stats else {},
    }


@app.get("/api/kpis")
def get_kpis():
    rows = query("""
        SELECT r.result_date, r.kpi_type, ROUND(r.score::numeric, 1) AS score, d.name AS domain_name
        FROM dq_quality_results r JOIN dq_data_domains d ON r.domain_id = d.id
        WHERE r.result_date >= CURRENT_DATE - INTERVAL '90 days'
        ORDER BY r.result_date
    """)
    return _ser(rows)


@app.get("/api/rules")
def get_rules():
    rows = query("""
        SELECT r.*, d.name AS domain_name
        FROM dq_quality_rules r JOIN dq_data_domains d ON r.domain_id = d.id
        ORDER BY r.name
    """)
    return _ser(rows)


@app.get("/api/incidents")
def get_incidents():
    rows = query("""
        SELECT i.*, d.name AS domain_name
        FROM dq_quality_incidents i JOIN dq_data_domains d ON i.domain_id = d.id
        ORDER BY i.created_at DESC
    """)
    return _ser(rows)


@app.get("/api/lineage/{table_fqn:path}")
def get_lineage(table_fqn: str):
    """Proxy to Unity Catalog lineage API."""
    try:
        w = get_workspace_client()
        headers = w.config.authenticate()
        host = w.config.host.rstrip('/')
        resp = http_requests.get(
            f"{host}/api/2.0/lineage-tracking/table-lineage",
            params={"table_name": table_fqn},
            headers=headers, timeout=30
        )
        return resp.json()
    except Exception as e:
        return {"error": str(e), "upstreams": [], "downstreams": []}


@app.get("/api/bdr")
def get_bdr():
    rows = query("""
        SELECT b.*, d.name AS domain_name
        FROM dq_bdr_conciliation b JOIN dq_data_domains d ON b.domain_id = d.id
        ORDER BY b.conciliation_date DESC
    """)
    return _ser(rows)


# ---------------------------------------------------------------------------
# Genie Space Integration
# ---------------------------------------------------------------------------
GENIE_SPACE_ID = "01f12e478a2a1218bed888797d8d478a"


class GenieRequest(BaseModel):
    pergunta: str


@app.post("/api/genie")
def genie_endpoint(req: GenieRequest):
    """Query Genie Space in natural language."""
    try:
        w = get_workspace_client()
        host = w.config.host.rstrip('/')
        headers = w.config.authenticate()
        headers["Content-Type"] = "application/json"

        # Start conversation
        start_resp = http_requests.post(
            f"{host}/api/2.0/genie/spaces/{GENIE_SPACE_ID}/start-conversation",
            json={"content": req.pergunta},
            headers=headers, timeout=30,
        )
        start_resp.raise_for_status()
        data = start_resp.json()
        conv_id = data["conversation_id"]
        msg_id = data["message_id"]

        # Poll until completed (max 60s)
        for attempt in range(20):
            time.sleep(3)
            poll_resp = http_requests.get(
                f"{host}/api/2.0/genie/spaces/{GENIE_SPACE_ID}/conversations/{conv_id}/messages/{msg_id}",
                headers=headers, timeout=30,
            )
            poll_resp.raise_for_status()
            msg = poll_resp.json()
            status = msg.get("status", "")

            if status == "COMPLETED":
                answer = ""
                sql_query = ""
                result_table = []
                for att in msg.get("attachments", []):
                    if "text" in att:
                        t = att["text"]
                        answer = t.get("content", "") if isinstance(t, dict) else str(t)
                    if "query" in att:
                        q = att["query"]
                        sql_query = q.get("query", "")
                        result_table = q.get("result", {}).get("row_count", 0)
                return {"resposta": answer, "sql_gerado": sql_query, "status": "COMPLETED"}
            elif status in ("FAILED", "CANCELLED"):
                return {"resposta": f"Genie retornou: {status}", "status": status}

        return {"resposta": "Timeout aguardando resposta do Genie", "status": "TIMEOUT"}
    except Exception as e:
        logger.error("Genie error: %s", e)
        return {"resposta": f"Erro: {str(e)}", "status": "ERROR"}


# ---------------------------------------------------------------------------
# Tags (Unity Catalog)
# ---------------------------------------------------------------------------
@app.post("/api/tags/{table_fqn:path}")
def set_tags(table_fqn: str, tags: dict):
    """Set UC Tags on a table."""
    try:
        tags_str = ", ".join([f"'{k}' = '{v}'" for k, v in tags.items()])
        # Try as TABLE first, then as VIEW
        try:
            run_dbsql_query(f"ALTER TABLE {table_fqn} SET TAGS ({tags_str})")
        except Exception:
            run_dbsql_query(f"ALTER VIEW {table_fqn} SET TAGS ({tags_str})")
        return {"status": "ok", "tags_set": len(tags)}
    except Exception as e:
        return {"status": "error", "error": str(e)}


@app.get("/api/tags/{table_fqn:path}")
def get_tags(table_fqn: str):
    """Get UC Tags from a table via information_schema."""
    try:
        parts = table_fqn.split(".")
        if len(parts) != 3:
            return {"table": table_fqn, "tags": {}}
        catalog, schema, table = parts
        rows = run_dbsql_query(
            f"SELECT tag_name, tag_value FROM {catalog}.information_schema.table_tags "
            f"WHERE catalog_name = '{catalog}' AND schema_name = '{schema}' AND table_name = '{table}'"
        )
        tags = {r["tag_name"]: r["tag_value"] for r in rows}
        return {"table": table_fqn, "tags": tags}
    except Exception as e:
        return {"table": table_fqn, "tags": {}, "error": str(e)}


# ---------------------------------------------------------------------------
# Lineage - list tables in schema
# ---------------------------------------------------------------------------
@app.get("/api/lineage-tables")
def list_lineage_tables():
    """List all monitored tables across UC schemas."""
    all_tables = []
    schemas = ['dq_rc18', 'credito', 'risco', 'contabil', 'regulatorio']
    for schema in schemas:
        try:
            rows = run_dbsql_query(f"SHOW TABLES IN santander_credito_app_catalog.{schema}")
            for r in rows:
                name = r.get('tableName', r.get('table_name', ''))
                if name:
                    all_tables.append(f"santander_credito_app_catalog.{schema}.{name}")
        except Exception:
            pass
    # Also list views
    try:
        rows = run_dbsql_query("SHOW VIEWS IN santander_credito_app_catalog.dq_rc18")
        for r in rows:
            name = r.get('viewName', r.get('namespace', ''))
            if name and name not in [t.split('.')[-1] for t in all_tables]:
                all_tables.append(f"santander_credito_app_catalog.dq_rc18.{name}")
    except Exception:
        pass
    return {"tables": sorted(all_tables)}


# ---------------------------------------------------------------------------
# Create Rule
# ---------------------------------------------------------------------------
class RuleCreate(BaseModel):
    domain_id: int
    name: str
    description: str = ""
    rule_type: str
    target_table: str
    target_column: str = ""
    threshold: float = 95.0
    severity: str = "error"


@app.post("/api/rules")
def create_rule(rule: RuleCreate):
    """Create a new quality rule."""
    rows = execute_returning("""
        INSERT INTO dq_quality_rules (domain_id, name, description, rule_type, target_table, target_column, threshold, severity, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'draft')
        RETURNING id, name, status
    """, (rule.domain_id, rule.name, rule.description, rule.type if hasattr(rule, 'type') else rule.rule_type,
          rule.target_table, rule.target_column, rule.threshold, rule.severity))
    return _ser(rows)[0] if rows else {"error": "Failed to create rule"}


# ---------------------------------------------------------------------------
# Domains list
# ---------------------------------------------------------------------------
@app.get("/api/domains")
def get_domains():
    rows = query("SELECT * FROM dq_data_domains ORDER BY name")
    return _ser(rows)


# ---------------------------------------------------------------------------
# Serve React SPA
# ---------------------------------------------------------------------------
if FRONTEND_DIR.exists():
    app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIR / "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        if full_path.startswith("api/"):
            raise HTTPException(404, "Not found")
        file_path = FRONTEND_DIR / full_path
        if file_path.is_file():
            return FileResponse(str(file_path))
        return FileResponse(str(FRONTEND_DIR / "index.html"))
